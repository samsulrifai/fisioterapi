</div>
<!-- JS -->
<script src="<?= base_url() ?>assets/auth/vendor/jquery/jquery.min.js"></script>
<script src="<?= base_url() ?>assets/auth/js/main.js"></script>
</body><!-- This templates was made by Colorlib (https://colorlib.com) -->

</html>