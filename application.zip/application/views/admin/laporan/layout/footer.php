<table class="table table-borderless" style="margin-top: 50px;">
    <tbody>

        <!-- <tr>
            <td style=" text-align: right;">
                Bojonegoro, <?= date('d M Y') ?></td>
            <td></td>
        </tr>
        <tr style="background-color: #fff;  ">
            <td style="text-align: right;">
                Kepala Bagian Keuangan
            </td>
            <td></td>
        </tr>
        <tr>
            <td style="text-align: right;">
                <img src=" <?= base_url() ?>assets/datakoperasi/stempel.png" width="20%"></td>
            <td></td>
        </tr>
        <tr style="background-color: #fff;  ">
            <td style="text-align: right;">
                Zainal Malik</td>
            <td></td>
        </tr> -->
    </tbody>
</table>

</body>

</html>